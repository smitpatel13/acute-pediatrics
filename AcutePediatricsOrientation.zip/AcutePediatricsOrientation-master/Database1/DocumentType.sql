﻿CREATE TABLE [dbo].[DocumentType]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(10) NOT NULL
)

